# Agent 开发能力

本目录由版本化 `agentic-dev` Release **agentic-dev@0.0.0-rc.1+51db05801382** 安装。

- Consumer 的根 `AGENTS.md`、产品 / 需求 / 系统架构 / 技术 / 项目文档继续由当前 Repository 自己拥有；
- 发布 Skill 位于 `.agents/skills/**`；
- 机器生成的 Skill locator 位于 `.agents/release/skill-index.json`；
- installed release provenance 位于 `.agents/release/manifest.json`；
- 普通运行不得在线读取 `agentic-dev` Source Repository 补流程或规则。

本文件只解释安装边界，不复制 Skill Procedure、项目 Roadmap、Current Gate 或手工维护的 Skill inventory。

Source commit: `51db05801382b74ee01601f391305fcbbff98db3`
